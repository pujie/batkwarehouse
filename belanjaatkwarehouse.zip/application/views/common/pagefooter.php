<div class="footer">
    <div class="footer-inner">
        2020 &copy; Belanjaatk.
    </div>
    <div class="footer-tools">
        <span class="go-top">
        <i class="icon-angle-up"></i>
        </span>
    </div>
</div>
