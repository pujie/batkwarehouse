<head>
	<meta charset="utf-8" />
	<title>BelanjaATK</title>
	<meta content="width=device-width, initial-scale=1.0" name="viewport" />
	<meta content="" name="description" />
	<meta content="" name="author" />
	<!-- BEGIN GLOBAL MANDATORY STYLES -->
	<link href="/assets/metronics/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
	<link href="/assets/metronics/plugins/bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet" type="text/css"/>
	<link href="/assets/metronics/plugins/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css"/>
	<link href="/assets/metronics/css/style-metro.css" rel="stylesheet" type="text/css"/>
	<link href="/assets/metronics/css/style.css" rel="stylesheet" type="text/css"/>
	<link href="/assets/metronics/css/style-responsive.css" rel="stylesheet" type="text/css"/>
	<link href="/assets/metronics/css/themes/default.css" rel="stylesheet" type="text/css" id="style_color"/>
	<link href="/assets/metronics/plugins/uniform/css/uniform.default.css" rel="stylesheet" type="text/css"/>
	<!-- END GLOBAL MANDATORY STYLES -->
	<!-- BEGIN PAGE LEVEL STYLES -->
	<!-- END PAGE LEVEL STYLES -->
	<link rel="shortcut icon" href="favicon.ico" />
</head>
