<script type="text/javascript" src="/assets/metronics/plugins/ckeditor/ckeditor.js"></script>  
<script type="text/javascript" src="/assets/metronics/plugins/bootstrap-fileupload/bootstrap-fileupload.js"></script>
<script type="text/javascript" src="/assets/metronics/plugins/chosen-bootstrap/chosen/chosen.jquery.min.js"></script>
<script type="text/javascript" src="/assets/metronics/plugins/select2/select2.min.js"></script>
<script type="text/javascript" src="/assets/metronics/plugins/bootstrap-wysihtml5/wysihtml5-0.3.0.js"></script> 
<script type="text/javascript" src="/assets/metronics/plugins/bootstrap-wysihtml5/bootstrap-wysihtml5.js"></script>
<script type="text/javascript" src="/assets/metronics/plugins/bootstrap-toggle-buttons/static/js/jquery.toggle.buttons.js"></script>
<script type="text/javascript" src="/assets/metronics/plugins/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
<script type="text/javascript" src="/assets/metronics/plugins/bootstrap-datetimepicker/js/bootstrap-datetimepicker.js"></script>
<script type="text/javascript" src="/assets/metronics/plugins/clockface/js/clockface.js"></script>
<script type="text/javascript" src="/assets/metronics/plugins/bootstrap-daterangepicker/date.js"></script>
<script type="text/javascript" src="/assets/metronics/plugins/bootstrap-daterangepicker/daterangepicker.js"></script> 
<script type="text/javascript" src="/assets/metronics/plugins/bootstrap-colorpicker/js/bootstrap-colorpicker.js"></script>  
<script type="text/javascript" src="/assets/metronics/plugins/bootstrap-timepicker/js/bootstrap-timepicker.js"></script>
<script type="text/javascript" src="/assets/metronics/plugins/jquery-inputmask/jquery.inputmask.bundle.min.js"></script>   
<script type="text/javascript" src="/assets/metronics/plugins/jquery.input-ip-address-control-1.0.min.js"></script>
<script type="text/javascript" src="/assets/metronics/plugins/jquery-multi-select/js/jquery.multi-select.js"></script>   
<script src="/assets/metronics/plugins/bootstrap-modal/js/bootstrap-modal.js" type="text/javascript" ></script>
<script src="/assets/metronics/plugins/bootstrap-modal/js/bootstrap-modalmanager.js" type="text/javascript" ></script> 
<script src="/assets/metronics/plugins/jquery.pwstrength.bootstrap/src/pwstrength.js" type="text/javascript" ></script>
<script src="/assets/metronics/plugins/bootstrap-switch/static/js/bootstrap-switch.js" type="text/javascript" ></script>
<script src="/assets/metronics/plugins/jquery-tags-input/jquery.tagsinput.min.js" type="text/javascript" ></script>
