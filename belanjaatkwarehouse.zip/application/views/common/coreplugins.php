<script src="/assets/metronics/plugins/jquery-1.10.1.min.js" type="text/javascript"></script>
<script src="/assets/metronics/plugins/jquery-migrate-1.2.1.min.js" type="text/javascript"></script>
<!-- IMPORTANT! Load jquery-ui-1.10.1.custom.min.js before bootstrap.min.js to fix bootstrap tooltip conflict with jquery ui tooltip -->
<script src="/assets/metronics/plugins/jquery-ui/jquery-ui-1.10.1.custom.min.js" type="text/javascript"></script>      
<script src="/assets/metronics/plugins/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
<script src="/assets/metronics/plugins/bootstrap-hover-dropdown/twitter-bootstrap-hover-dropdown.min.js" type="text/javascript" ></script>
<!--[if lt IE 9]>
<script src="/assets/metronics/plugins/excanvas.min.js"></script>
<script src="/assets/metronics/plugins/respond.min.js"></script>  
<![endif]-->   
<script src="/assets/metronics/plugins/jquery-slimscroll/jquery.slimscroll.min.js" type="text/javascript"></script>
<script src="/assets/metronics/plugins/jquery.blockui.min.js" type="text/javascript"></script>  
<script src="/assets/metronics/plugins/jquery.cookie.min.js" type="text/javascript"></script>
<script src="/assets/metronics/plugins/uniform/jquery.uniform.min.js" type="text/javascript" ></script>
