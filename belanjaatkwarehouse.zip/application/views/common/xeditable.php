<script type="text/javascript" src="/assets/metronics/plugins/select2/select2.min.js"></script>
<script type="text/javascript" src="/assets/metronics/plugins/bootstrap-wysihtml5/wysihtml5-0.3.0.js"></script> 
<script type="text/javascript" src="/assets/metronics/plugins/bootstrap-wysihtml5/bootstrap-wysihtml5.js"></script>
<script type="text/javascript" src="/assets/metronics/plugins/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
<script type="text/javascript" src="/assets/metronics/plugins/bootstrap-datetimepicker/js/bootstrap-datetimepicker.js"></script>
<script type="text/javascript" src="/assets/metronics/plugins/moment.min.js"></script>
<script type="text/javascript" src="/assets/metronics/plugins/jquery.mockjax.js"></script>
<!-- END PLUGINS USED BY X-EDITABLE -->
<!-- BEGIN X-EDITABLE PLUGIN -->
<script type="text/javascript" src="/assets/metronics/plugins/bootstrap-editable/bootstrap-editable/js/bootstrap-editable.min.js"></script>
<script type="text/javascript" src="/assets/metronics/plugins/bootstrap-editable/inputs-ext/address/address.js"></script>
<script type="text/javascript" src="/assets/metronics/plugins/bootstrap-editable/inputs-ext/wysihtml5/wysihtml5.js"></script>   
