<script type="text/javascript" src="/assets/metronics/plugins/select2/select2.min.js"></script>
<script type="text/javascript" src="/assets/metronics/plugins/data-tables/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="/assets/metronics/plugins/data-tables/DT_bootstrap.js"></script>
