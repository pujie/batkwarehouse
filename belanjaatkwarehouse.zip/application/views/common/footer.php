<div class="page-footer">
    2020 &copy; Belanjaatk.
</div>
