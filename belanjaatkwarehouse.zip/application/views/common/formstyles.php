<link rel="stylesheet" type="text/css" href="/assets/metronics//plugins/bootstrap-fileupload/bootstrap-fileupload.css" />
<link rel="stylesheet" type="text/css" href="/assets/metronics//plugins/gritter/css/jquery.gritter.css" />
<link rel="stylesheet" type="text/css" href="/assets/metronics//plugins/chosen-bootstrap/chosen/chosen.css" />
<link rel="stylesheet" type="text/css" href="/assets/metronics//plugins/select2/select2_metro.css" />
<link rel="stylesheet" type="text/css" href="/assets/metronics//plugins/clockface/css/clockface.css" />
<link rel="stylesheet" type="text/css" href="/assets/metronics//plugins/bootstrap-wysihtml5/bootstrap-wysihtml5.css" />
<link rel="stylesheet" type="text/css" href="/assets/metronics//plugins/bootstrap-datepicker/css/datepicker.css" />
<link rel="stylesheet" type="text/css" href="/assets/metronics//plugins/bootstrap-timepicker/compiled/timepicker.css" />
<link rel="stylesheet" type="text/css" href="/assets/metronics//plugins/bootstrap-colorpicker/css/colorpicker.css" />
<link rel="stylesheet" type="text/css" href="/assets/metronics//plugins/bootstrap-toggle-buttons/static/stylesheets/bootstrap-toggle-buttons.css" />
<link rel="stylesheet" type="text/css" href="/assets/metronics//plugins/bootstrap-daterangepicker/daterangepicker.css" />
<link rel="stylesheet" type="text/css" href="/assets/metronics//plugins/bootstrap-datetimepicker/css/datetimepicker.css" />
<link rel="stylesheet" type="text/css" href="/assets/metronics//plugins/jquery-multi-select/css/multi-select-metro.css" />
<link href="/assets/metronics//plugins/bootstrap-modal/css/bootstrap-modal.css" rel="stylesheet" type="text/css"/>
<link href="/assets/metronics//plugins/bootstrap-switch/static/stylesheets/bootstrap-switch-metro.css" rel="stylesheet" type="text/css"/>
<link rel="stylesheet" type="text/css" href="/assets/metronics//plugins/jquery-tags-input/jquery.tagsinput.css" />
