<?php
class Common{
    function setdefaultmenustatus(){
        return array(    
            'salesstatus'=>'noactive',
            'kasirstatus'=>'noactive',
            'gudangstatus'=>'noactive',
            'entrygudangstatus'=>'noactive'
        );
    }
}